//
//  RootHideManagerController.m
//  RootHideManager
//
//  Preference Bundle for managing RootHide jailbreak hiding
//  Standalone deb package - no Dopamine dependency
//

#import "RootHideManagerController.h"
#import <UIKit/UIKit.h>
#import <Preferences/Preferences.h>

static NSString * const kBlacklistPath = @"/var/mobile/Library/Preferences/com.roothide.manager/blacklist.plist";
static NSString * const kSettingsPath = @"/var/mobile/Library/Preferences/com.roothide.manager/settings.plist";
static NSString * const kEnabledKey = @"enabled";
static NSString * const kBlacklistArrayKey = @"blacklist";

@implementation RootHideManagerController

#pragma mark - Initialization

- (instancetype)init {
    self = [super init];
    if (self) {
        _blacklist = [NSMutableArray new];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBlacklist];
}

#pragma mark - Specifiers (UI)

- (id)specifiers {
    if (_specifiers == nil) {
        NSMutableArray *specs = [NSMutableArray array];
        
        // Group: Status
        PSSpecifier *statusGroup = [PSSpecifier groupSpecifierWithName:@"Status"];
        statusGroup.footerText = @"RootHide hides jailbreak from blacklisted apps";
        [specs addObject:statusGroup];
        
        // Enable/Disable Toggle
        PSSpecifier *enableSpec = [PSSpecifier 
            preferenceSpecifierNamed:@"Enable RootHide"
            target:self
            set:@selector(setPreferenceValue:specifier:)
            get:@selector(readPreferenceValue:)
            detail:Nil
            cell:PSSwitchCell
            edit:Nil];
        [enableSpec setProperty:kEnabledKey forKey:@"key"];
        [enableSpec setProperty:@YES forKey:@"default"];
        [enableSpec setProperty:@YES forKey:@"enabled"];
        [specs addObject:enableSpec];
        
        // Current Mode Info
        PSSpecifier *modeSpec = [PSSpecifier 
            preferenceSpecifierNamed:@"Mode"
            target:self
            set:NULL
            get:@selector(modeDescription)
            detail:Nil
            cell:PSTitleValueCell
            edit:Nil];
        [modeSpec setProperty:@"" forKey:@"default"];
        [specs addObject:modeSpec];
        
        // Group: Blacklist Management
        PSSpecifier *blGroup = [PSSpecifier groupSpecifierWithName:@"Blacklist Management"];
        blGroup.footerText = @"Add apps by Bundle ID to hide jailbreak from them";
        [specs addObject:blGroup];
        
        // Blacklist Count
        PSSpecifier *countSpec = [PSSpecifier 
            preferenceSpecifierNamed:@"Blacklisted Apps"
            target:self
            set:NULL
            get:@selector(blacklistCount)
            detail:Nil
            cell:PSTitleValueCell
            edit:Nil];
        [countSpec setProperty:@"0 apps" forKey:@"default"];
        [specs addObject:countSpec];
        
        // Add to Blacklist Button
        PSSpecifier *addSpec = [PSSpecifier 
            preferenceSpecifierNamed:@"➕ Add App to Blacklist"
            target:self
            set:NULL
            get:NULL
            detail:Nil
            cell:PSButtonCell
            edit:Nil];
        [addSpec setProperty:@selector(addToBlacklist:) forKey:@"action"];
        [specs addObject:addSpec];
        
        // View Blacklist Button
        PSSpecifier *viewSpec = [PSSpecifier 
            preferenceSpecifierNamed:@"👁 View Blacklist"
            target:self
            set:NULL
            get:NULL
            detail:Nil
            cell:PSButtonCell
            edit:Nil];
        [viewSpec setProperty:@selector(viewBlacklist:) forKey:@"action"];
        [specs addObject:viewSpec];
        
        // Clear Blacklist Button
        PSSpecifier *clearSpec = [PSSpecifier 
            preferenceSpecifierNamed:@"🗑 Clear All Blacklist"
            target:self
            set:NULL
            get:NULL
            detail:Nil
            cell:PSButtonCell
            edit:Nil];
        [clearSpec setProperty:@selector(clearBlacklist:) forKey:@"action"];
        [specs addObject:clearSpec];
        
        // Group: Presets
        PSSpecifier *presetGroup = [PSSpecifier groupSpecifierWithName:@"Quick Add Presets"];
        presetGroup.footerText = @"Pre-configured app lists for common use cases";
        [specs addObject:presetGroup];
        
        // Banking Apps Preset
        PSSpecifier *bankingSpec = [PSSpecifier 
            preferenceSpecifierNamed:@"🏦 Add Vietnamese Banking Apps"
            target:self
            set:NULL
            get:NULL
            detail:Nil
            cell:PSButtonCell
            edit:Nil];
        [bankingSpec setProperty:@selector(addPresetBankingApps:) forKey:@"action"];
        [specs addObject:bankingSpec];
        
        // Detection Apps Preset
        PSSpecifier *detectionSpec = [PSSpecifier 
            preferenceSpecifierNamed:@"🛡️ Add Detection/Security Apps"
            target:self
            set:NULL
            get:NULL
            detail:Nil
            cell:PSButtonCell
            edit:Nil];
        [detectionSpec setProperty:@selector(addPresetDetectionApps:) forKey:@"action"];
        [specs addObject:detectionSpec];
        
        // Group: Apply
        PSSpecifier *applyGroup = [PSSpecifier groupSpecifierWithName:@"Apply Changes"];
        applyGroup.footerText = @"Restart SpringBoard to apply all changes";
        [specs addObject:applyGroup];
        
        // Apply & Respring Button
        PSSpecifier *applySpec = [PSSpecifier 
            preferenceSpecifierNamed:@"✅ Apply & Respring"
            target:self
            set:NULL
            get:NULL
            detail:Nil
            cell:PSButtonCell
            edit:Nil];
        [applySpec setProperty:@selector(applyAndRespring:) forKey:@"action"];
        [specs addObject:applySpec];
        
        _specifiers = specs;
    }
    
    return _specifiers;
}

#pragma mark - Preference Values

- (id)readPreferenceValue:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    
    if ([key isEqualToString:kEnabledKey]) {
        NSDictionary *settings = [NSDictionary dictionaryWithContentsOfFile:kSettingsPath];
        return [settings objectForKey:kEnabledKey] ?: @NO;
    }
    
    return @NO;
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    
    if ([key isEqualToString:kEnabledKey]) {
        NSMutableDictionary *settings = [NSMutableDictionary dictionaryWithContentsOfFile:kSettingsPath];
        if (!settings) {
            settings = [NSMutableDictionary dictionary];
        }
        [settings setObject:value forKey:key];
        [settings writeToFile:kSettingsPath atomically:YES];
        
        // Reload mode description
        [self reloadSpecifier:[self specifierForID:@"mode"]];
    }
}

- (NSString *)modeDescription {
    BOOL enabled = [[self readPreferenceValue:nil] boolValue]; // Simplified check
    NSDictionary *settings = [NSDictionary dictionaryWithContentsOfFile:kSettingsPath];
    if (settings) {
        enabled = [[settings objectForKey:kEnabledKey] boolValue];
    }
    return enabled ? @"✅ Active - Hiding from blacklist" : @"⚪ Inactive";
}

- (NSString *)blacklistCount {
    [self loadBlacklist];
    NSUInteger count = self.blacklist.count;
    return [NSString stringWithFormat:@"%lu app(s)", (unsigned long)count];
}

#pragma mark - Blacklist Management

- (void)loadBlacklist {
    @try {
        NSDictionary *plist = [NSDictionary dictionaryWithContentsOfFile:kBlacklistPath];
        NSArray *saved = [plist objectForKey:kBlacklistArrayKey];
        if (saved && [saved isKindOfClass:[NSArray class]]) {
            _blacklist = [saved mutableCopy];
        } else {
            _blacklist = [NSMutableArray new];
        }
    } @catch (NSException *exception) {
        NSLog(@"[RootHide] Load error: %@", exception.reason);
        _blacklist = [NSMutableArray new];
    }
}

- (void)saveBlacklist {
    @try {
        NSMutableDictionary *plist = [NSMutableDictionary dictionary];
        [plist setObject:self.blacklist forKey:kBlacklistArrayKey];
        [plist writeToFile:kBlacklistPath atomically:YES];
    } @catch (NSException *exception) {
        NSLog(@"[RootHide] Save error: %@", exception.reason);
    }
}

- (void)reloadData {
    [self loadBlacklist];
    [self reloadSpecifiers];
    [self reloadSpecifier:[self specifierForID:@"blacklist"]];
}

#pragma mark - Action Handlers

- (void)addToBlacklist:(id)sender {
    UIAlertController *alert = [UIAlertController 
        alertControllerWithTitle:@"Add to Blacklist" 
        message:@"Enter the Bundle ID of the app\n(e.g., com.vcb.IB)" 
        preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"com.example.app";
        textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        textField.autocorrectionType = UITextAutocorrectionTypeNo;
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Add" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *bundleID = alert.textFields.firstObject.text;
        bundleID = [bundleID stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        if (bundleID.length > 0 && ![self.blacklist containsObject:bundleID]) {
            [self.blacklist addObject:bundleID];
            [self saveBlacklist];
            [self reloadData];
            
            // Show success
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                UIAlertController *success = [UIAlertController 
                    alertControllerWithTitle:@"Added" 
                    message:[NSString stringWithFormat:@"%@ added to blacklist", bundleID]
                    preferredStyle:UIAlertControllerStyleAlert];
                [success addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
                [self presentViewController:success animated:YES completion:nil];
            });
        } else if ([self.blacklist containsObject:bundleID]) {
            UIAlertController *dup = [UIAlertController 
                alertControllerTitle:@"Already Exists" 
                message:@"This app is already in the blacklist."
                preferredStyle:UIAlertControllerStyleAlert];
            [dup addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:dup animated:YES completion:nil];
        }
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)viewBlacklist:(id)sender {
    [self loadBlacklist];
    
    if (self.blacklist.count == 0) {
        UIAlertController *empty = [UIAlertController 
            alertControllerTitle:@"Blacklist Empty" 
            message:@"No apps are currently blacklisted.\n\nUse 'Add App' or presets to add apps."
            preferredStyle:UIAlertControllerStyleAlert];
        [empty addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:empty animated:YES completion:nil];
        return;
    }
    
    NSMutableString *message = [NSMutableString string];
    [message appendFormat:@"Total: %lu app(s)\n\n", (unsigned long)self.blacklist.count];
    
    for (NSUInteger i = 0; i < self.blacklist.count; i++) {
        [message appendFormat:@"%lu. %@\n", (unsigned long)(i + 1), self.blacklist[i]];
    }
    
    UIAlertController *alert = [UIAlertController 
        alertControllerTitle:@"Current Blacklist" 
        message:message 
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)clearBlacklist:(id)sender {
    [self loadBlacklist];
    
    if (self.blacklist.count == 0) {
        UIAlertController *alreadyEmpty = [UIAlertController 
            alertControllerTitle:@"Already Empty" 
            message:@"The blacklist is already empty."
            preferredStyle:UIAlertControllerStyleAlert];
        [alreadyEmpty addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alreadyEmpty animated:YES completion:nil];
        return;
    }
    
    UIAlertController *confirm = [UIAlertController 
        alertControllerTitle:@"⚠️ Clear Blacklist?" 
        message:[NSString stringWithFormat:@"Remove all %lu app(s)?\n\nThis cannot be undone!", (unsigned long)self.blacklist.count]
        preferredStyle:UIAlertControllerStyleAlert];
    
    [confirm addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:@"Clear All" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [self.blacklist removeAllObjects];
        [self saveBlacklist];
        [self reloadData];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            UIAlertController *cleared = [UIAlertController 
                alertControllerTitle:@"Cleared" 
                message:@"All apps removed from blacklist."
                preferredStyle:UIAlertControllerStyleAlert];
            [cleared addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:cleared animated:YES completion:nil];
        });
    }]];
    
    [self presentViewController:confirm animated:YES completion:nil];
}

- (void)addPresetBankingApps:(id)sender {
    [self loadBlacklist];
    
    NSArray *bankingApps = @[
        @"com.vietinbank.iBank",
        @"com.vcb.IB",
        @"com.techcombank.business",
        @"com.mbmobile",
        @"com.acb.ACBMobileBanking",
        @"com.vib.VIBMobileBanking",
        @"com.babk.BABMobileBanking",
        @"com.agribank.DigiBank",
        @"vnpay.NapAsVnPay",
    ];
    
    int added = 0;
    for (NSString *bundleID in bankingApps) {
        if (![self.blacklist containsObject:bundleID]) {
            [self.blacklist addObject:bundleID];
            added++;
        }
    }
    
    [self saveBlacklist];
    [self reloadData];
    
    NSString *msg = added > 0 ?
        [NSString stringWithFormat:@"Added %d Vietnamese banking apps!", added] :
        @"All banking apps already in blacklist.";
    
    UIAlertController *result = [UIAlertController 
        alertControllerTitle:@"🏦 Banking Apps" 
        message:msg
        preferredStyle:UIAlertControllerStyleAlert];
    [result addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:result animated:YES completion:nil];
}

- (void)addPresetDetectionApps:(id)sender {
    [self loadBlacklist];
    
    NSArray *detectionApps = @[
        @"com.apple.dt.Xcode",
        @"com.bugsnag.Bugsnag",
        @"io.fabric.sdk.ios",
        @"com.microsoft.IntuneMAM",
        @"com.vmware.horizon",
    ];
    
    int added = 0;
    for (NSString *bundleID in detectionApps) {
        if (![self.blacklist containsObject:bundleID]) {
            [self.blacklist addObject:bundleID];
            added++;
        }
    }
    
    [self saveBlacklist];
    [self reloadData];
    
    NSString *msg = added > 0 ?
        [NSString stringWithFormat:@"Added %d detection/security apps!", added] :
        @"All detection apps already in blacklist.";
    
    UIAlertController *result = [UIAlertController 
        alertControllerTitle:@"🛡️ Detection Apps" 
        message:msg
        preferredStyle:UIAlertControllerStyleAlert];
    [result addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:result animated:YES completion:nil];
}

- (void)applyAndRespring:(id)sender {
    [self saveBlacklist];
    
    BOOL enabled = NO;
    NSDictionary *settings = [NSDictionary dictionaryWithContentsOfFile:kSettingsPath];
    if (settings) {
        enabled = [[settings objectForKey:kEnabledKey] boolValue];
    }
    
    NSString *message = [NSString stringWithFormat: 
        @"Settings saved!\n\n"
        @"• RootHide: %@\n"
        @"• Blacklisted: %lu app(s)\n\n"
        @"Tap 'Respring Now' to restart SpringBoard and apply.",
        enabled ? @"ENABLED ✅" : @"DISABLED ⚪",
        (unsigned long)self.blacklist.count];
    
    UIAlertController *confirm = [UIAlertController 
        alertControllerTitle:@"💾 Apply Changes?" 
        message:message
        preferredStyle:UIAlertControllerStyleAlert];
    
    [confirm addAction:[UIAlertAction actionWithTitle:@"Later" style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:@"Respring Now" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        // Trigger respring via Darwin notification
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFSTR("com.roothide.manager.respring"),
            NULL,
            NULL,
            TRUE
        );
    }]];
    
    [self presentViewController:confirm animated:YES completion:nil];
}

@end
