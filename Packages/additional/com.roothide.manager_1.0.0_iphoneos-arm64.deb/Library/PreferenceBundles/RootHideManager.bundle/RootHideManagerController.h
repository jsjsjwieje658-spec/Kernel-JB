//
//  RootHideManagerController.h
//  RootHideManager
//
//  Preference Bundle for managing RootHide jailbreak hiding
//  Blacklist management UI for iOS Settings
//

#import <Preferences/PSListController.h>

@interface RootHideManagerController : PSListController

// Data
@property (nonatomic, strong) NSMutableArray *blacklist;
@property (nonatomic, assign) BOOL rootHideEnabled;

// Actions
- (void)toggleRootHide:(id)sender;
- (void)addToBlacklist:(id)sender;
- (void)viewBlacklist:(id)sender;
- (void)clearBlacklist:(id)sender;
- (void)addPresetBankingApps:(id)sender;
- (void)addPresetDetectionApps:(id)sender;
- (void)applyAndRespring:(id)sender;

// Helpers
- (void)loadBlacklist;
- (void)saveBlacklist;
- (void)reloadData;

@end
