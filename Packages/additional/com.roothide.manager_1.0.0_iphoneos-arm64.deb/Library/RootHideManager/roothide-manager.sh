#!/bin/bash
# RootHide Manager - Main Launcher for Settings
# This script provides the UI when tapped in Settings

source /Library/RootHideManager/settings.sh

# Use a simple dialog approach (works without GUI framework)
show_menu() {
    clear
    echo "================================"
    echo "   RootHide Manager v1.0.0"
    echo "================================"
    echo ""
    
    # Get current status
    ENABLED=$(/usr/bin/defaults read "$RH_SETTINGS" enabled 2>/dev/null || echo "0")
    COUNT=$(plutil -extract "blacklist" raw "$RH_BLACKLIST" 2>/dev/null | grep -c "<string>" || echo "0")
    
    echo "Status: $([ "$ENABLED" = "1" ] && echo '✅ ENABLED' || echo '⚪ DISABLED')"
    echo "Blacklisted: $COUNT app(s)"
    echo ""
    echo "--- MENU ---"
    echo "1) Toggle RootHide"
    echo "2) Add app to blacklist"
    echo "3) View blacklist"
    echo "4) Remove from blacklist"
    echo "5) Clear blacklist"
    echo "6) Add banking apps preset"
    echo "7) Add detection apps preset"
    echo "8) Apply & Respring"
    echo "0) Exit"
    echo ""
    echo -n "Select option: "
}

toggle_root_hide() {
    CURRENT=$(/usr/bin/defaults read "$RH_SETTINGS" enabled 2>/dev/null || echo "0")
    if [ "$CURRENT" = "1" ]; then
        /usr/bin/defaults write "$RH_SETTINGS" enabled -bool NO
        echo "RootHide DISABLED ⚪"
    else
        /usr/bin/defaults write "$RH_SETTINGS" enabled -bool YES
        echo "RootHide ENABLED ✅"
    fi
}

add_to_blacklist() {
    echo -n "Enter Bundle ID (e.g., com.vcb.IB): "
    read BUNDLE_ID
    
    if [ -z "$BUNDLE_ID" ]; then
        echo "Error: Bundle ID cannot be empty"
        return
    fi
    
    # Check if already exists
    if grep -q "$BUNDLE_ID" "$RH_BLACKLIST"; then
        echo "⚠️ $BUNDLE_ID already in blacklist"
        return
    fi
    
    # Add to plist (simple insertion before </array>)
    TEMP_FILE=$(mktemp)
    sed "s|</array>|    <string>$BUNDLE_ID</string>\n</array>|" "$RH_BLACKLIST" > "$TEMP_FILE"
    mv "$TEMP_FILE" "$RH_BLACKLIST"
    chown mobile:mobile "$RH_BLACKLIST"
    
    echo "✅ Added $BUNDLE_ID to blacklist"
}

view_blacklist() {
    echo ""
    echo "=== Current Blacklist ==="
    grep -o '<string>[^<]*</string>' "$RH_BLACKLIST" | sed 's/<[^>]*>//g' | nl
    echo ""
    TOTAL=$(grep -c '<string>' "$RH_BLACKLIST" || echo "0")
    echo "Total: $TOTAL app(s)"
}

remove_from_blacklist() {
    view_blacklist
    echo ""
    echo -n "Enter Bundle ID to remove: "
    read BUNDLE_ID
    
    if [ -z "$BUNDLE_ID" ]; then
        return
    fi
    
    # Remove from plist
    TEMP_FILE=$(mktemp)
    sed "/<string>$BUNDLE_ID<\/string>/d" "$RH_BLACKLIST" > "$TEMP_FILE"
    mv "$TEMP_FILE" "$RH_BLACKLIST"
    chown mobile:mobile "$RH_BLACKLIST"
    
    echo "✅ Removed $BUNDLE_ID (if it existed)"
}

clear_blacklist() {
    echo -n "Are you sure? (y/N): "
    read CONFIRM
    
    if [ "$CONFIRM" = "y" ] || [ "$CONFIRM" = "Y" ]; then
        # Clear array content
        cat > "$RH_BLACKLIST" << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>blacklist</key>
    <array/>
</dict>
</plist>
PLIST
        chown mobile:mobile "$RH_BLACKLIST"
        echo "🗑 Blacklist cleared"
    else
        echo "Cancelled"
    fi
}

add_banking_apps() {
    BANKING_APPS="com.vietinbank.iBank com.vcb.IB com.techcombank.business com.mbmobile com.acb.ACBMobileBanking com.vib.VIBMobileBanking com.babk.BABMobileBanking com.agribank.DigiBank vnpay.NapAsVnPay"
    ADDED=0
    
    for APP in $BANKING_APPS; do
        if ! grep -q "$APP" "$RH_BLACKLIST"; then
            TEMP_FILE=$(mktemp)
            sed "s|</array>|    <string>$APP</string>\n</array>|" "$RH_BLACKLIST" > "$TEMP_FILE"
            mv "$TEMP_FILE" "$RH_BLACKLIST"
            ADDED=$((ADDED + 1))
        fi
    done
    
    chown mobile:mobile "$RH_BLACKLIST"
    echo "🏦 Added $ADDED Vietnamese banking apps"
}

add_detection_apps() {
    DETECTION_APPS="com.apple.dt.Xcode com.bugsnag.Bugsnag io.fabric.sdk.ios com.microsoft.IntuneMAM com.vmware.horizon"
    ADDED=0
    
    for APP in $DETECTION_APPS; do
        if ! grep -q "$APP" "$RH_BLACKLIST"; then
            TEMP_FILE=$(mktemp)
            sed "s|</array>|    <string>$APP</string>\n</array>|" "$RH_BLACKLIST" > "$TEMP_FILE"
            mv "$TEMP_FILE" "$RH_BLACKLIST"
            ADDED=$((ADDED + 1))
        fi
    done
    
    chown mobile:mobile "$RH_BLACKLIST"
    echo "🛡️ Added $ADDED detection apps"
}

apply_and_respring() {
    echo "💾 Saving settings..."
    sleep 1
    echo "🔄 Restarting SpringBoard..."
    killall -9 SpringBoard
}

# Main loop
while true; do
    show_menu
    read CHOICE
    
    case "$CHOICE" in
        1) toggle_root_hide ;;
        2) add_to_blacklist ;;
        3) view_blacklist ;;
        4) remove_from_blacklist ;;
        5) clear_blacklist ;;
        6) add_banking_apps ;;
        7) add_detection_apps ;;
        8) apply_and_respring ;;
        0) exit 0 ;;
        *) echo "Invalid option" ;;
    esac
    
    echo ""
    echo "Press Enter to continue..."
    read DUMMY
done
