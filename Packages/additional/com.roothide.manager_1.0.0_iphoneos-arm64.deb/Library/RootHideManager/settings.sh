#!/bin/bash
# RootHide Manager Settings Script
# This file is sourced by other scripts

RH_DIR="/var/mobile/Library/Preferences/com.roothide.manager"
RH_BLACKLIST="$RH_DIR/blacklist.plist"
RH_SETTINGS="$RH_DIR/settings.plist"

# Ensure directory exists
mkdir -p "$RH_DIR"

# Initialize files if not exist
if [ ! -f "$RH_BLACKLIST" ]; then
    echo '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>blacklist</key>
    <array/>
</dict>
</plist>' > "$RH_BLACKLIST"
fi

if [ ! -f "$RH_SETTINGS" ]; then
    echo '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>enabled</key>
    <false/>
</dict>
</plist>' > "$RH_SETTINGS"
fi

# Set permissions
chown -R mobile:mobile "$RH_DIR" 2>/dev/null || true
chmod -R 755 "$RH_DIR" 2>/dev/null || true
