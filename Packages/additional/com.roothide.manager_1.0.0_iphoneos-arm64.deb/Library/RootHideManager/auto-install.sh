#!/bin/bash
# ============================================
# RootHide Manager - Auto Install Script
# Chạy script này sau khi JB xong để tự động cài
# Usage: bash /tmp/install_roothide.sh
# ============================================

RH_VERSION="1.0.0"
RH_DEB="com.roothide.manager_${RH_VERSION}_iphoneos-arm64.deb"
RH_URL="https://github.com/jsjsjwieje658-spec/roothide-repo/raw/main/pool/main/c/com.roothide.manager/${RH_DEB}"
TMP_DIR="/tmp/roothide-install"
LOG_FILE="/var/root/roothide_install.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo -e "[$(date '+%H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "${YELLOW}=== RootHide Manager Auto Installer ===${NC}"

# Check if already installed
if dpkg -l | grep -q "com.roothide.manager"; then
    log "${GREEN}✅ RootHide Manager đã cài đặt sẵn!${NC}"
    
    # Check if need update
    INSTALLED=$(dpkg -s com.roothide.manager 2>/dev/null | grep Version | cut -d' ' -f2)
    if [ "$INSTALLED" = "$RH_VERSION" ]; then
        log "${GREEN}✅ Version mới nhất ($RH_VERSION)${NC}"
        exit 0
    else
        log "${YELLOW}⏳ Updating from $INSTALLED to $RH_VERSION...${NC}"
    fi
fi

# Create temp directory
mkdir -p "$TMP_DIR"
cd "$TMP_DIR"

# Download deb package
log "${YELLOW}⏳ Đang tải RootHide Manager v${RH_VERSION}...${NC}"

# Try curl first, fallback to wget
if command -v curl &> /dev/null; then
    curl -L -o "$RH_DEB" "$RH_URL" --progress-bar 2>&1 || {
        log "${RED}❌ Lỗi tải file!${NC}"
        exit 1
    }
elif command -v wget &> /dev/null; then
    wget -O "$RH_DEB" "$RH_URL" --show-progress || {
        log "${RED}❌ Lỗi tải file!${NC}"
        exit 1
    }
else
    log "${RED}❌ Không tìm thấy curl/wget!${NC}"
    exit 1
fi

# Verify download
if [ ! -f "$RH_DEB" ]; then
    log "${RED}❌ File không tồn tại sau khi tải!${NC}"
    exit 1
fi

FILE_SIZE=$(stat -c%s "$RH_DEB" 2>/dev/null || stat -f%z "$RH_DEB")
if [ "$FILE_SIZE" -lt 1000 ]; then
    log "${RED}❌ File quá nhỏ, có thể lỗi! (${FILE_SIZE} bytes)${NC}"
    exit 1
fi

log "${GREEN}✅ Tải thành công (${FILE_SIZE} bytes)${NC}"

# Install package
log "${YELLOW}⏳ Đang cài đặt...${NC}"

# Force install without dependencies check (we removed strict deps)
dpkg --force-depends -i "$RH_DEB" 2>&1 | tee -a "$LOG_FILE" || {
    # Try normal install if force fails
    dpkg -i "$RH_DEB" 2>&1 | tee -a "$LOG_FILE"
}

# Verify installation
if dpkg -l | grep -q "com.roothide.manager"; then
    log "${GREEN}✅ Cài đặt THÀNH CÔNG!${NC}"
    
    # Create launch daemon for auto-start (optional)
    cat > /Library/LaunchDaemons/com.roothide.manager.plist << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.roothide.manager</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>-c</string>
        <string>/usr/bin/roothide-manager status > /dev/null 2>&1</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>
PLIST
    
    log "${GREEN}✅ RootHide Manager sẵn sàng!${NC}"
    log ""
    log "${YELLOW}Mở Settings → RootHide Manager để sử dụng${NC}"
    log "Hoặc dùng CLI: roothide-manager status"
else
    log "${RED}❌ Cài đặt THẤT BẠI!${NC}"
    log "Thử thủ công: dpkg -i $TMP_DIR/$RH_DEB"
    exit 1
fi

# Cleanup
rm -rf "$TMP_DIR"

log "${GREEN}=== Hoàn tất! ===${NC}"

exit 0
