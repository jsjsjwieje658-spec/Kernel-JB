#!/bin/bash
# ============================================
# RootHide Manager - Post-Jailbreak Auto Install
# Đặt script này vào Dopamine để chạy sau JB
# 
# Vị trí đề xuất:
# - /var/jb/usr/bin/post-jb-hook.sh (rootless)
# - Hoặc tích hợp vào Dopamine's bootstrap
# ============================================

RH_INSTALL_SCRIPT="/Library/RootHideManager/auto-install.sh"
RH_MARKER="/var/.roothide_manager_installed"

# Chỉ chạy 1 lần (kiểm tra marker)
if [ -f "$RH_MARKER" ]; then
    exit 0
fi

# Đợi network sẵn sàng (max 30 giây)
WAIT_COUNT=0
until ping -c 1 -W 1 github.com &> /dev/null || [ $WAIT_COUNT -ge 30 ]; do
    sleep 1
    WAIT_COUNT=$((WAIT_COUNT + 1))
done

# Kiểm tra nếu script cài đặt tồn tại
if [ -f "$RH_INSTALL_SCRIPT" ]; then
    bash "$RH_INSTALL_SCRIPT" && touch "$RH_MARKER"
else
    # Fallback: Cài đặt trực tiếp nếu script không tồn tại
    RH_DEB_URL="https://github.com/jsjsjwieje658-spec/roothide-repo/raw/main/pool/main/c/com.roothide.manager/com.roothide.manager_1.0.0_iphoneos-arm64.deb"
    RH_TMP="/tmp/rh_manager.deb"
    
    # Tải
    curl -sL -o "$RH_TMP" "$RH_DEB_URL" 2>/dev/null || wget -qO "$RH_TMP" "$RH_DEB_URL" 2>/dev/null
    
    # Cài
    if [ -f "$RH_TMP" ] && [ $(stat -c%s "$RH_TMP" 2>/dev/null || stat -f%z "$RH_TMP") -gt 1000 ]; then
        dpkg --force-depends -i "$RH_TMP" 2>/dev/null || dpkg -i "$RH_TMP" 2>/dev/null
        rm -f "$RH_TMP"
        touch "$RH_MARKER"
    fi
fi

exit 0
